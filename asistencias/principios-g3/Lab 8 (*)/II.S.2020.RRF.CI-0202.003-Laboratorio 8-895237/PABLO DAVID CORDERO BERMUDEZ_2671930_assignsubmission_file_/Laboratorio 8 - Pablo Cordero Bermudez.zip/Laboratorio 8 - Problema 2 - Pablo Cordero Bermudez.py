#Métodos 

def encontrar_numero_cercano(objetivo, valor_1, valor_2):
  primer_posibiliad = abs(objetivo - valor_1)
  segunda_posibiliad = abs(objetivo - valor_2)
  #En caso de que el valor 1 sea el más cercano
  if primer_posibiliad < segunda_posibiliad:
    return valor_1

  #En caso de que el valor 2 sea el más cercano
  elif segunda_posibiliad < primer_posibiliad:
    return valor_2

  #En caso de que ambos esten a la misma distancia
  elif primer_posibiliad == segunda_posibiliad:
    return "Ambos estan a la misma distancia"
    

#Programa principal 

print("Programa para determinar el número más cercano a un objetivo")

#inicio

try:
  numero_objetivo = float(input("\nIngrese un número objetivo: "))

  valor_1 = float(input("Ingrese un primer valor: "))

  valor_2 = float(input("Ingrese un segundo valor: "))

  resultado = encontrar_numero_cercano(numero_objetivo, valor_1, valor_2)

  print("\nEl número más cercano es:", resultado)


except ValueError:
  print("\nDebe ingresar un valor númerico")

#fin
