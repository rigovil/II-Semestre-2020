#Métodos 

def determinar_numero_objetivo(minimo, maximo):
  permitido = False 
  

  while permitido == False: #Mientras que el número no sea aceptado 
    try: 
      #Solititud al usuario de un número
      numero_elegido = int(input("Ingrese un número a analizar: "))

      #Verifica que el número elegido este dentro del rango permitido
      if minimo <= numero_elegido <= maximo:
        
        #Si cumple con todas las condiciones
        return numero_elegido
        permitido = True

      #En caso de que el número no este en el rango permitido
      else:  
        print("El número debe ser mayor a cero y menor o igual a 100")

    #En caso de que el valor no sea númerico o entero
    except ValueError:
      print("El valor no es permitido")

#Programa principal

#CONSTANTES
TITULO = print("Programa para determinar si un número es permitido")

MINIMO = 1
MAXIMO = 100



#Inicio

#Se llama al método 
resultado = determinar_numero_objetivo(MINIMO, MAXIMO)
print("\nEl número", resultado,"es permitido")

#fin