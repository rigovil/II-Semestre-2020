#Métodos 

def determinar_numero_objetivo():
  permitido = False 
  while permitido == False: #Mientras que el número no sea aceptado 
    try: 
      #Solititud al usuario de un número
      numero_elegido = int(input("Ingrese un número a analizar: "))

      #Verifica que el número elegido sea positivo
      if numero_elegido > 0:
        
        #Si cumple con todas las condiciones
        return numero_elegido
        permitido = True

      #En caso de que el número no sea positivo
      else:  
        print("El número debe ser mayor a cero")

    #En caso de que el valor no sea númerico o entero
    except ValueError:
      print("El valor no es permitido")

#Programa principal

#Inicio

print("Programa para determinar si un número es permitido")

#Se llama al método 
resultado = determinar_numero_objetivo()
print("\nEl número", resultado,"es permitido")

#Fin