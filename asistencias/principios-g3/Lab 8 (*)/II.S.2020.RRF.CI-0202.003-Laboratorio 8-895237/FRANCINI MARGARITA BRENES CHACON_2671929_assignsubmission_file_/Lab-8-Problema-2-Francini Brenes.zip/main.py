#Programa para determinar el número más cercano a un número objetivo

#Se utiliza DEF para definir el método
#Se incluyen tres parámetros, uno para el objetivo y dos para los valores a comparar
def determinar_cercania(valor_objetivo,primer_valor,segundo_valor):
#Se utiliza valor absoluto para determinar la diferencia entre los valores
  diferencia_primer_valor = abs(valor_objetivo - primer_valor)

  diferencia_segundo_valor = abs(valor_objetivo - segundo_valor)
#Se utiliza IF para determinar cuál el valor que tiene mayor diferencia 
#RETURN devuelve el valor más cercano
  if diferencia_primer_valor >= diferencia_segundo_valor:
    return segundo_valor
  else:
    return primer_valor
    
#Programa 
print("Programa para encontrar el valor más cercano a un valor objetivo")

#Se utiliza TRY/EXCEPT para manejar excepciones
try:
  valor_objetivo = float(input("\nIngrese el valor objetivo:"))
  primer_valor = float(input("\nIngrese el primer valor:"))
  segundo_valor = float(input("\nIngrese el segundo valor:"))

#Se invoca al método
  resultado = determinar_cercania(valor_objetivo,primer_valor,segundo_valor)

  print("\nEl valor más cercano al valor objetivo es",resultado)

except ValueError:
  print("\nEl valor ingresado no es permitido")



