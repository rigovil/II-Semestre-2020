#Método para lograr un número entero positivo

#Se utiliza DEF para definir el método
#No se colocan parámetros porque hay un input en el método
def discriminar_entero_positivo():

  numero_valido = False
#Se usa WHILE para pedir el valor de nuevo siempre que no sea válido
  while numero_valido == False:
    try:
#Se utiliza INT para discrimar entre valores enteros y decimales
      valor_usuario = int(input("Ingrese el valor deseado:"))
#Se utiliza condicional IF para dejar de pedir el número si este es válido
      if valor_usuario > 0:
        numero_valido = True
#De lo contrario se indica el error y se pide de nuevo
      else:
       print("\nEl valor ingresado debe ser mayor que 0.\n")
#Si el valor es str se detecta un ValueError 
    except ValueError:
      print("\nEl valor ingresado no es permitido.\n")
#Un RETURN devuelve el valor válido
  return valor_usuario

#Programa principal

#Se invoca el método
numero_valido = discriminar_entero_positivo()
#Se imprime el número válido
print("\nEl número",numero_valido,"es válido")