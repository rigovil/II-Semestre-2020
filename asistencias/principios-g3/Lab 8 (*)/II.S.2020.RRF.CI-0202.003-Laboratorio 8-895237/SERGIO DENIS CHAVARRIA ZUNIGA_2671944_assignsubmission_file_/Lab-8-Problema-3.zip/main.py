#Método para obtener un numero entero positivo
def determinar_numero_valido():
  numero_valido = False #Variable booleana para empezar el "while"
  while numero_valido == False: #Comiezo del "while"
    try:#Manejo de exepciones
     valor_ingresado = int(input("Ingrese un número entero positivo: ")) #"input" para ingresar el número entero positivo
     #"if" para determinar que cuenta con la condiciones
     if valor_ingresado < 0:
       print("No es un número entero positivo")
     else:
       return valor_ingresado #Si es así se retorna el valor
       numero_valido = True # se determina una variable booleana para acabar el "while"
    except ValueError: #Exepción en caso de ingresar un valor incorrecto
      print("No es un número entero positivo")

##########################################################
#Programa principal
#Inicio
numero_entero_positivo = determinar_numero_valido()
print(numero_entero_positivo)
#Fin del progrmam principal 