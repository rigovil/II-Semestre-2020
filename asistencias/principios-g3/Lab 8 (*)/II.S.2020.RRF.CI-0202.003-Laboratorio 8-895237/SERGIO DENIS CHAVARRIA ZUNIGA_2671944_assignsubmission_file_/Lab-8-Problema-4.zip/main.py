#Método para obtener un numero entero positivo
#Parámetros: rango_1 y rango_2
def determinar_numero_valido(rango_1, rango_2):
  numero_valido = False #Variable booleana para empezar el "while"
  while numero_valido == False: #Comiezo del "while"
    try:#Manejo de exepciones
     valor_ingresado = int(input("Ingrese un número entero positivo: ")) #"input" para ingresar el número entero positivo
     #"if" para determinar que cuenta con la condiciones
     if rango_1 <= valor_ingresado <= rango_2 and valor_ingresado > 0:
       return valor_ingresado #Si es así se retorna el valor
       numero_valido = True # se determina una variable booleana para acabar el "while"
     else:
       print("No es número entero positivo o no se encuentra dentro del rango asignado")
    except ValueError: #Exepción en caso de ingresar un valor incorrecto
      print("El valor ingresado no es un número entero")

##########################################################
#Programa principal
#Inicio
print("Programa para determinar un número entero positivo dentro de un rango\n")
terminar_programa = False #Variable booleana para empezar el "while"
while terminar_programa == False:#Comiezo del "while"
  try: #Manejo de exepciones
    rango_positivo = False #Variable booleana para el "while"
    while rango_positivo == False:#Comienzo de "while"
      primer_rango = int(input("Ingrese el número del rango: ")) #"input" para determinar el rango
      segundo_rango = int(input("Ingrese el segundo número del rango: "))#"input" para determinar el rango
      if primer_rango and segundo_rango <= 0:
       print("Debe ser un rango de valores positivos")
      elif primer_rango > segundo_rango:
        print("El rango no puede ser decreciente")
      else:
        rango_positivo = True
    numero_entero_positivo = determinar_numero_valido(primer_rango, segundo_rango)#llamada al método
    print(numero_entero_positivo)
    terminar_programa = True # se determina una variable booleana para acabar el "while"
  except ValueError: #Exepción en caso de ingresar un valor incorrecto
    print("El rango debe ser en numeros enteros") 
#Fin del progrmam principal 