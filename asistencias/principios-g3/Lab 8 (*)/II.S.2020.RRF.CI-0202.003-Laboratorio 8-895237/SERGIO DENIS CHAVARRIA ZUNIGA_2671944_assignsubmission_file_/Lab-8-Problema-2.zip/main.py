#Programa para determinar la distancia entre números
#Método del cálculo de distancia
#Parámetros: objetivo, primer_valor, segundo_valor 
def calculo_distancia(objetivo, primer_valor, segundo_valor):
  #Se restan cada valor con el objetivo
  #Observar que se encierran en valor absoluto para que no hayan números negativos 
  resultado_primer_valor = abs(objetivo - primer_valor)
  resultado_segundo_valor = abs(objetivo - segundo_valor)
  #"if" para determinar cual numero es más cercano
  if resultado_primer_valor < resultado_segundo_valor:
    return primer_valor 
  elif resultado_segundo_valor < resultado_primer_valor:
    return segundo_valor
  else:
    return "ninguno, los dos son el mismo"

##########################################################
#Programa principal
#Inicio
print("Programa para determinar distancia entre dos números")

terminar_programa = False #Variable booleana para el "while"
while terminar_programa == False:
  try:#Manejo de excepciones
    objetivo_ingresado = float(input("Ingrese el número objetivo: ")) #Input del número objetivo
    primer_numero = float(input("Ingrese el primer número: ")) #Input del primer número 
    segundo_numero = float(input("Ingrese el segundo número: ")) #Input del segundo número
    numero_cercano = calculo_distancia(objetivo_ingresado, primer_numero, segundo_numero) #LLamado al método calculo_distancia
    print("El numero más cercano es",numero_cercano)#Impresión del número más cercano
    terminar_programa = True #Variable booleana para terminar el "while"
  except ValueError: #La exepción en caso de que haya un valor incorrecto
    print("El  valor ingresado no es permitido")
#Fin del programa principal
