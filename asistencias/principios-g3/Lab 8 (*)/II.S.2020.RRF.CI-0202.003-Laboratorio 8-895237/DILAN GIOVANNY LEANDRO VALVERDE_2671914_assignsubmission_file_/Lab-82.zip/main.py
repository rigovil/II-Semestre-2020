
#INICIO

#Método para obtener un valor entero, positivo, dentro de un rango por parte del usuario 

def numero_entero(primer_valor, segundo_valor #Los parámetros utilizados por el método definen los valores del rango
  numero_positivo = False
  while numero_positivo == False: #Se utiliza la estructura de repetición adecuada
    try:  #Se manejan las excepciones del problema 
      valor_usuario = int (input ("Digite un valor entero positivo: ")) #Se convierte el número a entero
      if valor_usuario >= 0: #Se evaluá que sea mayor a 0
        if primer_valor <= valor_usuario <= segundo_valor:
          print ("\n¡Muchas gracias!\n") 
          numero_positivo = True #Se evalúa que esté dentro del rango, se imprime un mensaje de finalización y se termina el ciclo while.
        else:
          print ("\nEl número digitado está fuera del rango\n")
      else: 
        print ("\nEl valor ingresado debe ser positivo\n")
    except ValueError:
      print ("\nEl valor ingresado no es válido\n")

#Programa para probar el método


metodo = numero_entero (30,70) #Se nombra una variable que se encargue de llamar el método a ejecución y se le dan como parámetros los valores del rango que se deseen, estos se pueden solicitar al usuario o incluso pueden ser variables independientes a las que se les asigna un valor, en este caso como solo se quiere probar el método, se realiza de manera sencilla. 

#FIN