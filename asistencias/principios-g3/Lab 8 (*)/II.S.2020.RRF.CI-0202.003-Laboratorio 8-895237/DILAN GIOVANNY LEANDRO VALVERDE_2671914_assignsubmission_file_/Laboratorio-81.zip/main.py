#Método para determinar el valor más cercano al primer valor brindado

def parametros_cercanos (primer_valor, segundo_valor, tercer_valor):
  numero_cercano = float
  primer_resta = (abs (primer_valor - segundo_valor))
  segunda_resta = (abs (primer_valor - tercer_valor))
  if primer_resta < segunda_resta: 
    numero_cercano = segundo_valor
  elif segunda_resta < primer_resta:
    numero_cercano = tercer_valor
  else:
    numero_cercano = (segundo_valor, tercer_valor)
  return numero_cercano
  
  
#Programa para saber que numero es más numero_cercano

#INICIO

print ("Programa para determinar el número más cercano al objetivo\n")

#Definir los números que se le van a pedir al usuario

primer_numero = float (input ("Digite el primer número: "))

segundo_numero = float (input ("Digite el segundo número: "))

tercer_numero = float (input ("Digite el tercer número: "))

numero_cercano = parametros_cercanos (primer_numero, segundo_numero, tercer_numero)

print ("\nEl/los número(s) más cercano(s) al primer valor es/son:" , numero_cercano)

#FIN