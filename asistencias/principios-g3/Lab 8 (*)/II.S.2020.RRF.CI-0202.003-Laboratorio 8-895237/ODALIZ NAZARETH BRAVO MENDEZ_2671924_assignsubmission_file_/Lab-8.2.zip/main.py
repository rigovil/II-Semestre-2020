#7
#20
#3

#7 - 20 = -13
#7 - 3 = 4

def determinar_valor_cercano (objetivo, segundo_valor, tercer_valor):
  valor_cercano = 0

  diferencia_segundo_valor = abs(objetivo-segundo_valor)
  diferencia_tercer_valor = abs(objetivo-tercer_valor)


  if diferencia_segundo_valor < diferencia_tercer_valor:
    valor_cercano = segundo_valor
  return valor_cercano

  if diferencia_tercer_valor < diferencia_segundo_valor:
    valor_cercano = tercer_valor
  return valor_cercano


#Programa principal

primer_valor = 5
segundo_valor = 115
tercer_valor = 50

try:
 resultado = determinar_valor_cercano(primer_valor, segundo_valor,
 tercer_valor)
  print (resultado)

  except ValueError:
    print("El valor ingresado no es permitido")