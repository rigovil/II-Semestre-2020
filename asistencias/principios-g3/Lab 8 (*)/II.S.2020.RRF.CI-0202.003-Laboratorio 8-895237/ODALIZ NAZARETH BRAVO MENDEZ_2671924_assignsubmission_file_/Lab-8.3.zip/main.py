#Método para determinar un numero válido del usuario
def obtener_numero_valido ():
  es_valido = False
  while es_valido == False:
    try:
      valor_usuario = int(input("Ingrese un número entero positivo:"))
      if valor_usuario > 0:
       #valor es correcto 
       es_valido = True 
      else:
        print("El numero debe seer mayor a cero")
    except ValueError:
      print("El valor ingresado no es permitido")
  
  return valor_usuario

#Programa Principal

valor_inicial = obtener_numero_valido()
print(valor_inicial)

