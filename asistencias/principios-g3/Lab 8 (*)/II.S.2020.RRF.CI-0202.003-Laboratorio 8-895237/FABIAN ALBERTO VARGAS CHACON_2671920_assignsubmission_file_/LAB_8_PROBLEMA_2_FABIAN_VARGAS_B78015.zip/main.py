#metodo para buscar cercania de objetivo
def cercania(Objetivo, numero1, numero2):
#busco distancias entre numero y objetivo
  resta1 = Objetivo - numero1

  resta2 =  Objetivo - numero2
  
#busco la solucion mas basica.
  if numero1 == numero2:
    return numero1

# hago valor absoluto para las distancias
  if resta1 < 0:
    resta1 = resta1 * -1

  if resta2 < 0:
    resta2 = resta2 * -1

#comparo todas las distancias
  if resta1 > resta2:
    return numero2

  elif resta1 < resta2:
    return numero1

  else:
    return numero1, numero2


try:
  objetivo=float(input("Ingrese el numero objetivo: "))
  numero1=float(input("Ingrese el numero 1: "))
  numero2=float(input("Ingrese el numero 2: "))

  print(cercania(objetivo, numero1, numero2))
except ValueError:
  print("Ingresó un valor no valido")