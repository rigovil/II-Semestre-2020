#metodo de hacer que el usuario ponga un numero positivo
def NumerosPos(numerom, numeroM):
  #while condicionado

  numeros_validos = False
  while numeros_validos == False:
    try:
      numero = int(input("Ingrese el valor: "))
      if numero >0:
        if numero > numerom and numero<numeroM: 
          numeros_validos = True
          #salida más facil
        else:
          numeros_validos=False
      else:
       numeros_validos=False
    except ValueError:
     numeros_validos=False
  return numero


numerom = int(input("Ingrese el numero menor del rango: "))
numeroM = int(input("Ingrese el numero mayor del rango: "))

NumerosPos(numerom, numeroM)