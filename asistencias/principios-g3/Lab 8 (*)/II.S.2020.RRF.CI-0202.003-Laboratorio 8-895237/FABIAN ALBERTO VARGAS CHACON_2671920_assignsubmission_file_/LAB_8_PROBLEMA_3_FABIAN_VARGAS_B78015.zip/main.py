#metodo de hacer que el usuario ponga un numero positivo
def NumerosPos():
  #while condicionado

  numeros_validos = False
  while numeros_validos == False:
    try:
      numero = int(input("Ingrese el valor: "))
      if numero > 0: 
        numeros_validos = True
        #salida más facil
      else:
       numeros_validos=False
    except ValueError:
     numeros_validos=False
  return numero


NumerosPos()