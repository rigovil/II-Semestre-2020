#Laboratorio 08
#B82190-Juan Ignacio Chaves Wong 
#CI-0202

#Inicio de programa_1:

print("   Problema#1:\n")

#Calculadora
#Tres opciones:
#Sumar dos números positivos
#Restar dos números positivos
#Salir 

#Métodos

#Sumar 
def sumar(primer_valor, segundo_valor):
  resultado = primer_valor + segundo_valor
  return resultado 

#Restar
def restar(primer_valor, segundo_valor):
  resultado = primer_valor - segundo_valor
  return resultado

#Multiplicación
def multiplicar(primer_valor,segundo_valor):
  resultado = primer_valor * segundo_valor
  return resultado

#División
def dividir(primer_valor, segundo_valor):
  resultado = primer_valor / segundo_valor
  return resultado


#Programa principal 
  print("Bienvenido al programa de calculadora")

terminar_programa = False

while terminar_programa == False:
#Desplegar menú
  print("\nMenú de opciones\n")
  print("1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Salir")
  
  try:
    operacion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if operacion_usuario == 1:

      #Suma
      print("\nSUMA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_suma = sumar(primer_numero, segundo_numero)
              print("\nEl resultado de la suma es: ",resultado_suma)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 2:
      #Resta
      print("\nRESTA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_resta = restar(primer_numero, segundo_numero)
              print("\nEl resultado de la resta es: ",resultado_resta)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 3:
      #Multiplicación
      print("\nMultiplicación\n")
      #Solicitar valores al usuario

      numeros_validos = False 

      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0:
            segundo_numero = float(input("Ingrese el segundo valor : "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_multiplicacion = multiplicar(primer_numero, segundo_numero)
              print("Él resultado de la multiplicación es: ", resultado_multiplicacion)
            else:
              print("Él número ingresado debe de ser mayor a cero")
          else:
            print("Él número ingresado debe de ser mayor a cero")
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 4:
      #División
      print("\nDivisión\n")
      #Solicitar valores al usuario

      numeros_validos = False 

      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0:
            segundo_numero = float(input("Ingrese el segundo valor : "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_division = dividir(primer_numero, segundo_numero)
              print("Él resultado de la división es: ", resultado_division)
            else:
              print("Él número ingresado debe de ser mayor a cero")
          else:
            print("Él número ingresado debe de ser mayor a cero")
        except ValueError:
          print("El valor ingresado no es permitido")


    elif operacion_usuario == 5:
      print("\nGracias por utilizar el programa")
      terminar_programa = True
    else:
      print("La operación indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")

#Fin de programa_1




#Inicio programa_2
print("\n   Problema #2\n")
#Metodos para determinar cual número es el mas cercano al valor objetivo 
def determinar_cercania (valor_1,valor_2,valor_3):

  numero_cercano = 0
  rango_1 = abs(valor_2 - valor_1)
  rango_2 = abs(valor_3 - valor_1)
  if (rango_1) < (rango_2):
    numero_cercano = valor_2
  elif (rango_1) > (rango_2):
    numero_cercano = valor_3
  elif (rango_1) == (rango_2):
    numero_cercano = valor_2
  return numero_cercano

#Programa Principal

print("\nBienvenidos al programa de la cercania\n ")

try:  
  #Se determinan los valores objetivos y a comparar
  primer_numero = float(input("Ingrese su primer valor( Número Objetivo ): "))
  segundo_numero = float(input("Ingrese su segundo valor: "))
  tercer_numero = float(input("Ingrese su tercer valor: "))

  print("\nLos valores son: ",primer_numero,segundo_numero,tercer_numero)

  # Prueba de que el metodo funciona
  resultado_comparacion = determinar_cercania(primer_numero,segundo_numero,tercer_numero)

  print("\nEl número más cercano al primer valor objetivo corresponde a: ",resultado_comparacion)

except ValueError:  
  print("\nEl valor ingresado no es permitido")


#Fin programa #2





#Inicio programa 3 y 4
print("\n   Programa 3 y 4 opcional\n")

#Metodo #3: obtener un npumero valido del usuario 
def obtener_numero_valido ():
  es_valido = False
  while es_valido == False:
    try:
      valor_usuario = int(input("Ingrese un número entero positivo: "))
      if valor_usuario > 0 and valor_usuario <= 100:
        #Quiere decir que el valor es correcto y que se encuentra dentro del rango de 0 y 100(problema opcional 4)
        es_valido = True
      else:
        print("\nEl número debe de ser mayor a cero y menor o igual a cien\n")
    except ValueError:
      print("\nEl valor ingresado no es permitido\n ")
    
  return valor_usuario
#Programa principal
valor_inicial = obtener_numero_valido()
print("\nEl número entero corresponde a: ",valor_inicial)

#Fin programa 3 y 4