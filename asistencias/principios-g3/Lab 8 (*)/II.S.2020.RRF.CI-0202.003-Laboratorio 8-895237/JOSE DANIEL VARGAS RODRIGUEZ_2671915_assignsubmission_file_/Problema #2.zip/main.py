#Laboratorio #8
#Problema #2

#Pedirle al usuario 3 números y determinar cuál es más cercano al primer número

#Métodos

def determinar_numero(valor_objetivo, valor_2, valor_3):
  valor_cercano = 0
  diferencia_segundo_valor = abs(valor_objetivo - valor_2)
  diferencia_tercer_valor = abs(valor_objetivo - valor_3)
  if diferencia_segundo_valor < diferencia_tercer_valor:
    valor_cercano = valor_2
  else:
    valor_cercano = valor_3
  return valor_cercano

#Programa principal

valor_objetivo = 10
valor_2 = 15
valor_3 = 6

print("El número más cercano es: ", str(determinar_numero(valor_objetivo, valor_2, valor_3)))
