#Laboratorio #8
#Problema #3

#Pedirle al usuario un número entero, flotante y que se encuentre en un rango de datos

valor_usuario = ""


#Métodos

def obtener_numero(valor_ingresado):
  es_valido = False
  while es_valido == False:
    try:
      valor_usuario = int(input("Ingrese un número entero positivo: "))
      if valor_usuario > 0 and 3 < valor_usuario < 5:
        es_valido = True
      elif valor_usuario > 0:
        print("El número debe estar entre 3 y 5")
      else: 
        print("El número debe ser mayor a cero ")
    except ValueError:
      print("El valor ingresado no es permitido")
  return valor_usuario


#Programa principal


obtener_numero(valor_usuario)


