#Parte 2
#inicio
#Metodo para buscar el numero mas cerca del objetivo
def determinar_valor_cercano(valor_1, valor_2, valor_3):
  valor_cercano = 0
  dif_valor2 = abs(valor_1-valor_2)
  dif_valor3 = abs(valor_1-valor_3)

  if dif_valor2 < dif_valor3:
   valor_cercano = valor_2
  return valor_cercano

  if dif_valor3 < dif_valor2:
   valor_cercano = valor_3
  return valor_cercano

#Programa principal
numero_1 = float(input("Indique un primer numero: "))
numero_2 = float(input("Indique un segundo numero: "))
numero_3 = float(input("Indique un tercer numero: "))
resultado = determinar_valor_cercano(numero_1, numero_2, numero_3)
print(resultado)
#fin

#Parte 3
#inicio
#Método para obtener un número válido
def obtener_numero_valido():
  terminar_programa = False
  while terminar_programa == False:
   try:
     valor_ingresado = int(input("Ingrese un valor: "))
     if valor_ingresado > 0:
       terminar_programa = True
     else:
       print("El número debe ser mayor a cero")
   except Exception:
     print("El valor ingresado no es permitido")
  return valor_ingresado

#Programa principal
valor_inicial = obtener_numero_valido()
print(valor_inicial)
#fin

