#Problema 4. Numero entero positivo dentro de un rango
print ("Problema 4. Programa del numero correcto en un rango \n\n")

#Metodo
def conseguir_numero_correcto_en_rango(primer_valor, segundo_valor):
  es_correcto = False
  while es_correcto == False:
    try:
      primer_numero = int(input("Ingrese el primer valor del rango: "))
      if primer_numero > 0: 
        segundo_numero = int(input("Ingrese el segundo valor del rango: "))
        if segundo_numero > 0:
          es_correcto = True
          if es_correcto == True:
            es_valido = False
            while es_valido == False:
              try:
                valor_usuario = int(input("Ingrese un numero entero positivo: "))
                if primer_numero < valor_usuario < segundo_numero:
                  es_valido = True
                else:
                  print("El numero debe ser mayor a cero y estar en el rango")
              except ValueError:
                print ("El valor ingresado no es correcto")
        else:
          print("El número ingresado debe ser mayor a cero")
      else:
          print("El número ingresado debe ser mayor a cero") 
    except ValueError:
        print("El valor ingresado no es permitido")

  return valor_usuario


#Programa principal
primer_numero = 0
segundo_numero = 0
valor_usuario = conseguir_numero_correcto_en_rango(primer_numero, segundo_numero)
print (valor_usuario)
