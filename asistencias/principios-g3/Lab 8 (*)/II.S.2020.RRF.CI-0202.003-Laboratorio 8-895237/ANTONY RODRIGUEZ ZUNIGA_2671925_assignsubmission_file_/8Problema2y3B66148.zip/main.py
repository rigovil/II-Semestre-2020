#Valor cercano

#Metodos
def obtener_valor_cercano(objetivo, segundo_valor, tercer_valor):
  valor_cercano = 0
  diferencia_segundo_valor= abs(objetivo-segundo_valor)
  diferencia_tercer_valor= abs(objetivo-tercer_valor)
  
  if diferencia_segundo_valor < diferencia_tercer_valor:
    valor_cercano= segundo_valor

  elif diferencia_tercer_valor < diferencia_segundo_valor:
    valor_cercano= tercer_valor

  return valor_cercano
    



#Programa principal
print ("Problema 2. Bienvenido al programa del valor cercano\n")

primer_valor = 10
segundo_valor = 20.5
tercer_valor = 25

resultado = obtener_valor_cercano (primer_valor, segundo_valor, tercer_valor)

print ("El valor mas cerca al objetivo es: ", resultado)

#Fin problema 2



#Problema 3. Numero entero positivo
print ("\n\n Problema 3. Programa del numero correcto \n\n")

#Metodo
def conseguir_numero_correcto():
  es_correcto = False
  while es_correcto == False:
    try:
      valor_usuario = int(input("Ingrese un numero entero positivo: "))
      if valor_usuario > 0:
        es_correcto = True

      else:
        print("El numero debe ser mayor a cero")
    except ValueError:
      print ("El valor ingresado no es correcto")

  
  return valor_usuario


#Programa principal
valor_inicial = conseguir_numero_correcto()
print (valor_inicial)



