#Problema 1. Calculadora de multiplicacion y división
#Métodos

#Sumar 
def multiplicar(primer_valor, segundo_valor):
  resultado = primer_valor * segundo_valor
  return resultado 

#Restar
def dividir(primer_valor, segundo_valor):
  resultado = primer_valor / segundo_valor
  return resultado

#Programa principal 

print("Bienvenido al programa de calculadora")

terminar_programa = False

while terminar_programa == False:

  
  print("\nMenú de opciones\n")
  print("1. Multiplicar\n2. Dividir\n3. Salir")
  
  try:
    operacion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if operacion_usuario == 1:

      #Multiplicar
      print("\nMULTIPLICACIÓN\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_multiplicacion = multiplicar(primer_numero, segundo_numero)
              print("\nEl resultado de la multiplicacion es: ",resultado_multiplicacion)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 2:
      print("\nDIVISIÓN\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_division = dividir(primer_numero, segundo_numero)
              print("\nEl resultado de la division es: ",resultado_division)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")
    
    elif operacion_usuario == 3:
      terminar_programa = True
    else:
      print("La operación indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")