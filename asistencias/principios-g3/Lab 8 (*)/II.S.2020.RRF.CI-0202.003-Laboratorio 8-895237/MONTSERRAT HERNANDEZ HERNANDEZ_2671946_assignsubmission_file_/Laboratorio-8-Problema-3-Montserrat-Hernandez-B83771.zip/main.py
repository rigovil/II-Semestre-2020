

#Lab 8, Problema 3, Montserrat Hernández 

#Método
#Este método es para obtener un número válido:

def obtener_numero_valido():

  valido=False

  while valido==False:

    try:

      valor_del_usuario=int(input("Ingrese un número entero positivo:"))

      if valor_del_usuario>0:
        valido=True
      #Si el numero ingresado no es mayor a 0:
      else:
        print("El número debe ser mayor a 0")
      
      #Si el valor ingresado no es positivo:

    except ValueError:
      print("Su valor ingresado no es positivo")  

  return valor_del_usuario    


#Programa principal

resultado=obtener_numero_valido()

print(resultado)