
#Lab 8, Problema 3, Montserrat Hernández 

#Método
#Este método es para obtener un número válido:

def obtener_numero_valido(primer_valor_rango,ultimo_valor_rango):

  valido=False

  while valido==False:

    try:

      valor_del_usuario=int(input("Ingrese un número entero positivo:"))

      if valor_del_usuario>0:

        
        if primer_valor_rango<=valor_del_usuario<=ultimo_valor_rango:

        
          valido=True

        else:
          print("El número se debe encontrar entre", primer_valor_rango ," y ", ultimo_valor_rango) 
      
      else:
        print("El numero debe ser mayor a 0")  

      
      #Si el valor ingresado no es positivo:

    except ValueError:
      print("Su valor ingresado no es permitido")  

  return valor_del_usuario    


#Programa principal

resultado=obtener_numero_valido(2,300)

print(resultado)