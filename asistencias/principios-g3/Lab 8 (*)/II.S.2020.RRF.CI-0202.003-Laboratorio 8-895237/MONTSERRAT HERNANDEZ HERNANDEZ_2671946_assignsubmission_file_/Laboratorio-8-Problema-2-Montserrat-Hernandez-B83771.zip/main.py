
#Lab 8, problema 2, Montserrat Hernández

#Este programa nos va a pedir un numero que será nuestro objetivo para saber cuales de los otros dos valores solicitados está más cerca de dicho objetivo.

#Método
#Determina cual valor está más cerca del número objetivo

def cercania_al_numero_objetivo(numero_objetivo,segundo_numero,tercer_numero):

  diferencia_segundo_numero=abs(numero_objetivo-segundo_numero)
  diferencia_tercer_numero=abs(numero_objetivo-tercer_numero)

  if diferencia_segundo_numero<diferencia_tercer_numero:
     return segundo_numero #este numero está más cerca del objetivo

  elif diferencia_segundo_numero>diferencia_tercer_numero:

   return tercer_numero#el tercer número está más cerca del número objetivo

  elif diferencia_segundo_numero==diferencia_tercer_numero:

    return segundo_numero and tercer_numero #si ambos números están a la misma distancia, nos va a retornar uno de los dos valores ingresados .
    
    
#Programa principal

print("\nVamos a determinar cual de dos numeros está más cercano al primer número dado:\n")

valor_correcto=False
#Hacemos un while en caso de que el usuario ingrese algo que no es permitido, de esta forma vuelve a pedir los valores.
while valor_correcto==False:

  try:
    #Pedimos los tres valores al usuario
    valor_objetivo=float(input("Ingrese el primer valor:"))
    segundo_valor=float(input("Ingrese el segundo valor:"))
    tercer_valor=float(input("Ahora ingrese el tercer valor:"))
    
    #Llamamos al método
    resultado_final=cercania_al_numero_objetivo(valor_objetivo,segundo_valor,tercer_valor)

    print()

    print("El valor más cercano al",str(valor_objetivo),"es",resultado_final)
    valor_correcto=True

  #En caso de que el usuario ingrese letras u espacios
  except ValueError:
   print("El valor ingreasado no es permitido")






  




