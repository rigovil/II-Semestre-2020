#Método que recibe solo números enteros positivos
def obtener_numero_entero_positivo(minimo,maximo):
	while True: #El while hace que siga pidiendo números
		try:
			valor = int(input("Ingrese un número entero positivo dentro del rango especificado: "))
		#El 'try' + el int hace que solo acepte números enteros

			if valor < 0:
				print("Favor ingresar un número positivo\n")
			#Este if se asegura de que el número sea positivo
			
			elif valor > maximo or valor < minimo:
				print("Favor ingresar un número dentro del rango\n")  
			#Este elif se asegura de que el número ingresado esté dentro del rango

			else:
				#Si todas las condiciones se cumplen, devuelve el número y rompe el ciclo
				return valor
				break
	
		except Exception:
 			print("Favor ingresar un número entero\n")
			 #Si ingresan un número decimal o texto, el try-except se lo dice al usuario

print(obtener_numero_entero_positivo(1,10))