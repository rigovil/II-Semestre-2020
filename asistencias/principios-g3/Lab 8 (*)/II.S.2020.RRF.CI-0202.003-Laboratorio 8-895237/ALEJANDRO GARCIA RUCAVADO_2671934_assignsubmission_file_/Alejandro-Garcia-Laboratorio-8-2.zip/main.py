#Método que compara dos valores al objetivo
def comparacion_valores(objetivo,valor1,valor2):
	distancia_valor1 = abs(objetivo - valor1)
	distancia_valor2 = abs(objetivo - valor2)
	#Obtiene la diferencia entre el valor y el objetivo, y usa valor absoluto para eliminar cualquier negativo y que este no afecte

	if distancia_valor1 == distancia_valor2:
		return valor1 
	#Si las distancias son iguales, devuelve el valor1 aunque podría devolver el otro sin problema
  
	elif distancia_valor1 < distancia_valor2:
		return valor1
  #La distancia menor la tiene el valor más cercano al objetivo
  
	else:
		return valor2
  

print(comparacion_valores(1,2,3))
print(comparacion_valores(-9,1,5))
print(comparacion_valores(-50,-48,5))
print(comparacion_valores(23,1,5))
print(comparacion_valores(23,1,-5))
print(comparacion_valores(23,-5,23))