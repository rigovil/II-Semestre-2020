#Programa que solo acepta numeros enteros positivos
#Definir método
def compobar_entero():
	asistente = True
	while asistente == True:
		try:
			numero = int(input("Ingrese un número entero positivo:"))
			if numero > 0:
				return numero			
			else:#si ingresa un valor negativo
				print("El número que ingreso no es válido")    		
		except Exception: #si ingresa un valor que no sea entero
			print ("El número que ingreso no es válido")
      
#programa principal 
resultado= compobar_entero() 