
#Programa que tertermina cual de 2 parámetros es más cercano a un tercer parámetro
#Definir métodos
#Método para comparar parámetros y conocer cual se acerca más al número objetivo  
def determinar_cercania(numero_objetivo, parametro_1, parametro_2):
  comprobar_1 = abs(numero_objetivo - parametro_1)
  comprobar_2 = abs(numero_objetivo - parametro_2)
  #condiciones
  if comprobar_1 < comprobar_2:
    return parametro_1 
  elif comprobar_1 > comprobar_2:
    return parametro_2
  elif comprobar_1 == comprobar_2:
    return parametro_1 
#Pide al usuario los datos
numero_objetivo= float(input("Ingrese el número objetivo:"))
primer_parametro =float(input("Ingrese el primer parámetro:"))
segundo_parametro =float(input("Ingrese el segundo parámetro:"))
#Invoca el método
print("El parámetro que más se acerca al número objetivo es",determinar_cercania(numero_objetivo,primer_parametro,segundo_parametro))