#Programa que solo acepta numeros enteros positivos
#Definir método
def compobar_entero(limite_menor, limite_mayor):
	asistente = True
	while asistente == True:
		try:
			numero = int(input("Ingrese un número entero positivo dentro del rango:"))
			if numero > limite_menor and numero < limite_mayor:
				return numero
      			
			else:#si ingresa un valor negativo
				print("El número que ingreso no es válido")    		
		except Exception: #si ingresa un valor que no sea entero
			print ("El número que ingreso no es válido")
           
#programa principal 
#pide que ingrese el rango
menor = int(input("Ingrese el límite menor:"))
if menor > 0:
  mayor = int(input("Ingrese el límite mayor:")) 
  if mayor > menor:
    resultado= compobar_entero(menor,mayor) 
  else:
    print("El límite mayor debe ser mayor al limite menor")
else:
 print("El límite menor debe ser mayor a cero") 