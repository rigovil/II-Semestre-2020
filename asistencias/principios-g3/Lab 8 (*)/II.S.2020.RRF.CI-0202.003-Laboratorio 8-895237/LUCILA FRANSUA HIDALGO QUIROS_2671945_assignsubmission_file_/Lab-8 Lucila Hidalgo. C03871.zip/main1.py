#Calculadora
#Tres opciones:
#Dividir dos números positivos
#Multiplicar dos números positivos
#Salir 

#Métodos

#Dividir
def dividir(dividendo, divisor):
  resultado = dividendo / divisor 
  return resultado 

#Multiplicar 
def multiplicar(valor_1,valor_2):
  resultado = valor_1 * valor_2
  return resultado

#Programa principal 

print("Bienvenido al programa de calculadora")

terminar_programa = False

while terminar_programa == False:
  #Desplegar menú
  print("\nMenú de opciones\n")
  print("1. Dividir\n2. Multiplicar\n3. Salir")
  
  try:
    operacion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if operacion_usuario == 1:

      #División 
      print("\nDivisión\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          dividendo = float(input("Ingrese el número que desea dividir: "))
          if dividendo > 0: 
            divisor = float(input("Ingrese el divisor: "))
            if divisor > 0:
              numeros_validos = True
              resultado_division = dividir(dividendo,divisor)
              print("\nEl resultado de la división es: ",resultado_division)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 2:
      #Multiplicación
      print("\nMultiplicación\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_factor = float(input("Ingrese el primer valor: "))
          if primer_factor > 0: 
            segundo_factor = float(input("Ingrese el segundo valor: "))
            if segundo_factor > 0:
              numeros_validos = True
              resultado_multiplicacion = multiplicar(primer_factor, segundo_factor)
              print("\nEl resultado de la multiplicación es: ",resultado_multiplicacion)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")
    
    elif operacion_usuario == 3:
      print("Fin del programa")
      terminar_programa = True
    else:
      print("La operaciónn indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")