#Definición de métodos

#Método para controlar entrada de un valor positivo entero (número natural)

def entrada_natural():
  finalizar_metodo = False
  while finalizar_metodo == False:
    try:
      valor = float(input("Ingrese un valor positivo entero: "))
      valor_entero = int(valor)
      #Se verifica que el valor sea positivo (el cero no es un número positivo)
      if valor_entero > 0:
        #Se verifica que el valor sea entero
        if valor == valor_entero:
          return int(valor)
        else:
          print("El valor ingresado no es entero")
      else:
        print("El valor ingresado no es positivo")
    except ValueError:
      print("El valor ingresado no es numérico")


#Programa principal
finalizar = False

while finalizar == False:
  print("\n\nEste programa tiene la función de probar un método.\n\nEl método retorna el valor digitado solo si este es positivo y entero.\n\nDigite 1 si desea probar el método, o digite 2 si desea finalizar el programa: ")
  opcion = int(input())
  if opcion == 1:
  #El usuario va a probar el programa
    print(entrada_natural())
    
  elif opcion == 2:
  #El usuario va a cerrar el programa
    finalizar = True
  else:
    print("La opción digitada no es válida")