#Problema 2

#Métodos
def comparar(valor1, valor2, valor3):
  #Se obtiene el valor absoluta de las diferencias
  primera_comparacion = abs(float(valor1) - float(valor2))
  segunda_comparacion = abs(float(valor1) - float(valor3))

  #Se comparan las diferencias para determinar el número más cercano al primer valor
  if primera_comparacion < segunda_comparacion:
    valor_cercano = valor2
  elif segunda_comparacion < primera_comparacion:
    valor_cercano = valor3
  elif primera_comparacion == segunda_comparacion:
    valor_cercano = valor2
  return valor_cercano

#Programa de prueba
print("Este programa obtiene 3 valores y determina el valor ingresado más cercano al primer valor\n")

numero1 = input("Ingrese el primer valor: ")
numero2 = input("Ingrese el segundo valor: ")
numero3 = input("Ingrese el tercer valor: ")

print("El valor ingresado más cercano al primer valor es ",comparar(numero1, numero2, numero3))