print('Bienvenido al programa!')
valor1 = int(input('\nIngrese el primer valor: '))
valor2 = int(input('\nIngrese el segundo valor: '))
valor3 = int(input('\nIngrese el tercer valor: '))

def calcularvalor(valor1,valor2,valor3):

  if abs(valor3 - valor1) > abs(valor2 - valor1):
    print('\nEl valor mas cercano al primer calor es ', valor1)

  elif abs(valor2 - valor1) > abs(valor3 - valor1):
    print('\nEl valor mas cercano al primer calor es ', valor2)

  else:
    print('\nLos valores son igual de cercanos al primer valor')

calcularvalor(valor1,valor2,valor3)