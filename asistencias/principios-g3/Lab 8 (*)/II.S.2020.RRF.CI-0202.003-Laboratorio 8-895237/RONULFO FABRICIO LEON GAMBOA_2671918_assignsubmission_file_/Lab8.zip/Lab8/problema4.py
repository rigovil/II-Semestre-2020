#Validación de ingreso de número entero positivo dado un rango
def obtener_entero_positivo(primer_valor_rango, ultimo_valor_rango):
  numero_valido = False
  while numero_valido == False:
    try:
      valor_ingresado = float(input("Ingrese un número entero: "))
      valor_entero = int(valor_ingresado)

      if valor_ingresado != 0 and valor_ingresado/valor_entero != 1:
        print("El número ingresado no es entero \n")      
      elif valor_entero > 0:
        if primer_valor_rango <= valor_entero <= ultimo_valor_rango:
          numero_valido = True
        else:
          print("El número ingresado no está dentro del rango\n")     
      else:
        print("El número ingresado no es positivo\n")
    except ValueError:
      print("Valor ingresado no es numérico\n")  
  return valor_entero

#Programa principal 
#EL PROGRAMA PRINCIPAL NO TIENE VALIDACIONES DEBIDO A QUE ES UNA PRUEBA

rango_inicio = int(input("Ingrese el inicio del rango (número entero): "))
rango_fin = int(input("Ingrese el fin del rango (número entero): "))

print("\nPRUEBA DEL MÉTODO\n")
resultado=obtener_entero_positivo(rango_inicio,rango_fin)

print("El valor entero ingresado es",resultado)
