#Validación de ingreso de número entero positivo
def obtener_entero_positivo():
  numero_valido = False
  while numero_valido == False:
    try:
      valor_ingresado = float(input("Ingrese un número entero: "))
      valor_entero = int(valor_ingresado)

      if valor_ingresado != 0 and valor_ingresado/valor_entero != 1:
        print("El número ingresado no es entero \n")      
      elif valor_entero > 0:
        numero_valido = True
      else:
        print("El número ingresado no es positivo\n")
    except ValueError:
      print("Valor ingresado no es numérico\n")  
  return valor_entero

#Programa principal 

resultado=obtener_entero_positivo()

print("El valor entero ingresado es",resultado)
