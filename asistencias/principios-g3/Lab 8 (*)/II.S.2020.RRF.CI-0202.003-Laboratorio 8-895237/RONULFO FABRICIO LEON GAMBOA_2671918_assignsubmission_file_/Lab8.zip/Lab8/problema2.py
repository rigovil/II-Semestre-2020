#Valor más cernano
def valor_cercano(primer_valor, segundo_valor, tercer_valor):
  if abs(primer_valor - segundo_valor) < abs(primer_valor - tercer_valor):
    return segundo_valor
  else:
    return tercer_valor

#Programa principal 
#EL PROGRAMA PRINCIPAL NO TIENE VALIDACIONES DEBIDO A QUE ES UNA PRUEBA, ESTE TAMPOCO ESTARÁ EN UN CICLO POR EL MISMO MOTIVO

primer_valor = float(input("Ingrese el primer valor: "))
segundo_valor = float(input("Ingrese el segundo valor: "))
tercer_valor = float(input("Ingrese el tercer valor: "))

resultado=valor_cercano(primer_valor, segundo_valor, tercer_valor)

print("El valor más cercano es",resultado)

