##INICIO
#Programa para determinar un valor cercano.

#Metodo
def determinar_valor_cercano(objetivo, segundo_valor, tercer_valor): 
  valor_cercano = 0
  diferencia_segundo_valor = abs (objetivo-segundo_valor)
  diferencia_tercer_valor = abs(objetivo-tercer_valor)
  
  if diferencia_segundo_valor <= diferencia_tercer_valor:
    valor_cercano = segundo_valor

  elif diferencia_segundo_valor >= diferencia_tercer_valor:
    valor_cercano = tercer_valor

  return valor_cercano



##Programa principal

#obtener valores de usuario
primer_valor = int(input("Ingrese el primer valor:"))
segundo_valor = int(input("\nIngrese el segundo valor:" ))
tercer_valor = int(input("\nIngrese el tercer valor:"))

#ejecucion
resultado_final = determinar_valor_cercano(primer_valor, segundo_valor, tercer_valor) 

print ("\n")
print (resultado_final)

##FINAL