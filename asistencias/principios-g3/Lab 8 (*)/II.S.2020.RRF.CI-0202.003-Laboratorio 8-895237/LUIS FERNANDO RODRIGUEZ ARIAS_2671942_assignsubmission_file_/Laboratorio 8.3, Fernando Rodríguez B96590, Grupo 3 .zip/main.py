#Programa que busca un número entero mayor que cero y lo devuelve

#Método
#El método evalua el valor ingresado, buscando que cumpla con los requisitos deseados 
def obtener_numero_valido():
  es_valido = False
  while es_valido == False:
    try:
      valor_ingresado = int(input("Ingrese un número entero positivo: "))
      if valor_ingresado > 0:
        es_valido = True
      else:
        print("El número debe ser mayor que cero")
    except ValueError:
      print("El valor ingresado no es valido")

  return valor_ingresado

#Programa principal
#Si el número cumple con lo deseado se imprime de vuelta
valor_inicial = obtener_numero_valido()
print(valor_inicial)