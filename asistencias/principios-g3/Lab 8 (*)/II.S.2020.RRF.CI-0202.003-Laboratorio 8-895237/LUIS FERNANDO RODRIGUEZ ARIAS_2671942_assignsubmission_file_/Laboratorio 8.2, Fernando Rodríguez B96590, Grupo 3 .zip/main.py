#Programa para determinar el valor más cercano al número objetivo, obtenido de 3 valores del usuario

def determinar_valor_aproximado(valor_objetivo, segundo_valor, tercer_valor):
  #Se determina una variable para la aproximación
  valor_aproximado = 0
  #Calculos de diferencia
  aproximacion_segundo_valor = abs(objetivo - segundo_valor)
  aproximacion_tercer_valor = abs(objetivo - tercer_valor)

  #Se define el valor más aproximado al objetivo
  if aproximacion_segundo_valor < aproximacion_tercer_valor:
    valor_aproximado = segundo_valor
  elif aproximacion_segundo_valor > aproximacion_tercer_valor:
    valor_aproximado = tercer_valor
  elif aproximacion_segundo_valor == aproximacion_tercer_valor:
    valor_aproximado = segundo_valor    

  return valor_aproximado

#Programa principal
print("Se le pediran 3 valores y se le retornara uno de ellos")

objetivo = int(input("\nIngrese el primer valor: "))
segundo_valor = int(input("Ingrese el segundo valor: "))
tercer_valor= int(input("Ingrese el tercer valor: "))

resultado = determinar_valor_aproximado(objetivo, segundo_valor, tercer_valor)

print("\n",resultado)