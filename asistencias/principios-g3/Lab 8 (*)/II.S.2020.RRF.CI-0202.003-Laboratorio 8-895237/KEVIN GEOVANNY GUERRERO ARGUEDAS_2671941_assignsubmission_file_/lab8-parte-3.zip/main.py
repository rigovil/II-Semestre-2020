#programa para ingresar numeros enteros positivos

#inicio

#metodo
def numero_entero():

  numeros_validos = False
  try:
    numero = int(input("Ingrese un numero entero: "))
    if numero >= 0:
      numeros_validos = True
      respuesta = print("\nEl número entero que introdujo es: ",numero)
    else:
      print("\nNo se permiten números negativos como: ",numero)
  except ValueError:
    print("El valor ingresado no es permitido")
  return respuesta


#programa principal

terminar_programa = False

while terminar_programa == False:
  #desplegar menu
  print("\nMenú de opciones\n")
  print("1. Ingresar\n\n0. Salir\n")

  try:
    menu = int(input("In grese la opción que desea realizar en el menú: "))
    if menu == 1:
      respuesta = numero_entero()
    elif menu == 0:
       terminar_programa = True 
    else:
        print("La opción indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")




