#programa para saber cual numero se encuentra más cerca del número objetivo

#inicio

#metodo

def numero_cercano_objetivo(numero1,numero2,numero3):

  A=abs(numero2-numero1)
  B=abs(numero3-numero1)

  if A < B:
    resultado=print("El numero más cercano es",numero2)
  elif B < A:
    resultado=print("El número más cercanos es",numero3)
  return(resultado)


#programa principal

terminar_programa = False

while terminar_programa == False:
  #desplegar menú
  print("\nMenú de opciones\n")
  print("1. Ingresar\n\n0. Salir\n")
  try:
    menu = int(input("Ingrese la opcion de menú que desea realizar: "))
    if menu == 1:

      numero1=float(input("Ingrese el primer número: "))
      numero2=float(input("Ingrese el segundo numero: "))
      numero3=float(input("Ingrese el tercer número: "))

      respuesta = numero_cercano_objetivo(numero1,numero2,numero3)
      print(respuesta)
    elif menu == 0:
      terminar_programa = True
    else:
      print("La opción indicada no es correcta")
  except ValueError:
    print("\nValor no permitido\n")