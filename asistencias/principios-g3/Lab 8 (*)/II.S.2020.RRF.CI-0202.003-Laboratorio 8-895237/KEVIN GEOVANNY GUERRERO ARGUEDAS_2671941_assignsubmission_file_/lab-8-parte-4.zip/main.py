#programa para ingresar numeros enteros positivos

#inicio

#metodo
def Rev_Rango(Minimo,Maximo,numero):
  if Minimo < numero < Maximo:
    respuesta = print("\nEl numero entero",numero,"esta dentro del rango",Minimo,"y",Maximo)
  elif Minimo <= numero <= Maximo:
     respuesta = print("\nEl número entero",numero,"es igual a 1 o a los dos niveles del rango",Minimo,"y",Maximo)
  else:
    respuesta = ("\nEl numero entero",numero,"No esta dentro del rango",Minimo,"y",Maximo)
  return respuesta

#programa principal
terminar_programa = False

while terminar_programa == False:
  #Desplegar menú
  print("\nMenú de opciones\n")
  print("1. Ingresar rango y número entero\n0. Salir\n")

  try:
    menu = int(input("Ingrese la opción del menú que desea realizar: "))
    if menu == 1:
      numeros_validos = False
      while numeros_validos == False:
        try:
          Minimo = int(input("Ingrese el valor minimo del ranfo: "))
          if Minimo >= 0:
            Maximo = int(input("Ingrese el valor máximo del rango: "))
            if Maximo >= 0:
              numeros_validos = True
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
           print("El número ingresado debe ser mayor a cero")
          numero = int(input("Ingrese un número entero: "))
          if numero >= 0:
            numeros_validos = True
            print("\nEl número entero introducido es: ",numero)
            Respuesta = Rev_Rango(Minimo,Maximo,numero)
          else:
            print("\nNo se permiten numeros negativos como: ",numero)
        except ValueError:
          print("\El valor ingresado no es permitido")
    elif menu == 0:
      terminar_programa = True
    else:
      print("La opción indicada no es correcta")
  except ValueError:
    print("\nEl valor ingresado no es permitido")

  
