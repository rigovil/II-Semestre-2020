#Calculadora
#Tres opciones:
#Sumar dos números positivos
#Restar dos números positivos
#Salir 

#Métodos

#Sumar 
def sumar(primer_valor, segundo_valor):
  resultado = primer_valor + segundo_valor
  return resultado 

#Restar
def restar(primer_valor, segundo_valor):
  resultado = primer_valor - segundo_valor
  return resultado

#Multiplicar
def multiplicar(primer_valor,segundo_valor):
  resultado = primer_valor*segundo_valor
  return resultado

#División
def division(primer_valor,segundo_valor):
  resultado = primer_valor/segundo_valor
  return resultado


#Programa principal 

print("Bienvenido al programa de calculadora")

terminar_programa = False

while terminar_programa == False:
  #Desplegar menú
  print("\nMenú de opciones\n")
  print("1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Salir")
  
  try:
    operacion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if operacion_usuario == 1:

      #Suma
      print("\nSUMA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_suma = sumar(primer_numero, segundo_numero)
              print("\nEl resultado de la suma es: ",resultado_suma)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 2:
      #Resta
      print("\nRESTA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_resta = restar(primer_numero, segundo_numero)
              print("\nEl resultado de la resta es: ",resultado_resta)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")
    
    #Mod multiplicar
    elif operacion_usuario == 3:
      print("\n Multiplicación\n")
      #solicitar valores al usuario

      numeros_validos = False

      while numeros_validos == False:
        try:
          primer_numero =float(input("Ingrese el primer valor: "))
          if primer_numero > 0:
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_Multi = multiplicar(primer_numero,segundo_numero)
              print("\nEl resultado de la multiplicacion es: ",resulyado_Multi)
            else:
             print("El número ingresado debe ser mayor a cero")
          else:
            print("El valor ingresado debe ser mayor a cero")
        except ValueError:
          print("El valor ingresado no es permitido")

    #Mod division
    elif operacion_usuario == 4:
      print("\nDivisión\n")
      #solicitar valores al usuario

      numeros_validos = False

      while numeros_validos == False:
        try:
          primer_numero =float(input("Ingrese el primer valor: "))
          if primer_numero > 0:
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_divide = division(primer_numero,segundo_numero)
              print("\nEl resultado de la du+ivisión es: ",resultado_divide)
            else:
             print("El número ingresado debe ser mayor a cero")
          else:
            print("El valor ingresado debe ser mayor a cero")
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 5:
      terminar_programa = True
    else:
      print("La operación indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")


   

