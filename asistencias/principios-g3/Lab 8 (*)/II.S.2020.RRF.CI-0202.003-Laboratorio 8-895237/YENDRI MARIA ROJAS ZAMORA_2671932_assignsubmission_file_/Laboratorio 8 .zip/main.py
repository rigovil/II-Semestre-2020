#Calculadora
#Cinco opciones:
#Sumar dos números positivos
#Restar dos números positivos
#Multiplicar dos números
#Dividir dos números
#Salir

#Métodos

#Sumar 
def sumar(primer_valor, segundo_valor):
  resultado = primer_valor + segundo_valor
  return resultado 

#Restar
def restar(primer_valor, segundo_valor):
  resultado = primer_valor - segundo_valor
  return resultado

#Multiplicar
def multiplicar(primer_valor, segundo_valor):
  resultado = primer_valor * segundo_valor 
  return resultado

#División 
def dividir(primer_valor, segundo_valor):
  try:
    resultado = primer_valor / segundo_valor
    return resultado
  except ZeroDivisionError:
    print("No se permite la división con cero")


#Programa principal 

print("Bienvenido al programa de calculadora")

terminar_programa = False

while terminar_programa == False:
#Desplegar menú
  print("\nMenú de opciones\n")
  print("1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Salir\n")
  
  try:
    operacion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if operacion_usuario == 1:

      #Suma
      print("\nSUMA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_suma = sumar(primer_numero, segundo_numero)
              print("\nEl resultado de la suma es: ",resultado_suma)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 2:
      #Resta
      print("\nRESTA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_resta = restar(primer_numero, segundo_numero)
              print("\nEl resultado de la resta es: ",resultado_resta)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")
    
    elif operacion_usuario == 3: 
      #Multiplicación
      print("\nMultiplicación\n")
      #Solicitar los valores al usuario
      try:
        primer_numero= float(input("Ingrese el primer valor: "))
        segundo_numero = float(input("Ingrese el segundo valor: "))
        resultado_multiplicación = multiplicar(primer_numero, segundo_numero)
        print("\nEl resultado de la multiplicación es: ",resultado_multiplicación)
      except ValueError:
        print("Debe ingresar formato numérico")

    elif operacion_usuario == 4: 
      #División
      print("\nDivisión\n")
      #Solicitar los valores al usuario
      try:
        primer_numero= float(input("Ingrese el primer valor: "))
        segundo_numero = float(input("Ingrese el segundo valor: "))
        resultado_división = dividir(primer_numero, segundo_numero)
        print("\nEl resultado de la división es: ",resultado_división)
      except ValueError:
        print("Debe ingresar formato numérico")

    elif operacion_usuario == 5:
      #al elegir la opción salir, se finaliza el programa
      terminar_programa = True
    else:
      print("La operación indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")


#Método para definir valor cercano   
def determinar_valor_cercano (objetivo, segundo_valor, tercer_valor):
  valor_cercano= 0
  diferencia_segundo_valor= abs(objetivo-segundo_valor)
  diferencia_tercer_valor= abs(objetivo-tercer_valor)
  #Dependiendo de cual valor sea el menor, será asignado a la variable valor_cercano
  if diferencia_segundo_valor <diferencia_tercer_valor:
    valor_cercano= segundo_valor
  else:
    valor_cercano= tercer_valor
  return valor_cercano

  #Programa principal
finalizar_programa= False
while finalizar_programa == False:
  try:
    #El usuario ingresa los tres valores, el primero se define como objetivo
    objetivo= float(input("Ingrese un valor: "))
    segundo_valor=float(input("Ingrese un valor: "))
    tercer_valor=float(input("Ingrese un valor: "))
    #al llamar al método se logra definir cual es el valor cercano
    resultado = determinar_valor_cercano(objetivo, segundo_valor, tercer_valor)
    print("El valor más cercano es: ",resultado)
    finalizar_programa= True
  except ValueError:
    print("Debe ingresar formato numérico")

#Método para obtener un número válido del usuario
def obtener_numero_valido():
  es_valido= False
  while es_valido== False:
    try:
      valor_usuario= int(input("Ingrese un número entero positivo: "))
      if valor_usuario >0:
        # Si es mayor que cero, el valor es correcto
        es_valido= True
      else:
          print("El número debe ser mayor a cero")
    except ValueError:
      print("El valor ingresado no es permitido")
  return valor_usuario

#Programa principal
valor_inicial= obtener_numero_valido()
print(valor_inicial)

#Método para obtener un número válido del usuario según rango
def obtener_numero_valido(valor_incial_rango, valor_final_rango):
  es_valido= False
  while es_valido== False:
    try:
      valor_usuario= int(input("Ingrese un número entero positivo: "))
      if valor_usuario>0 and valor_incial_rango<=valor_usuario<=valor_final_rango:
        #Si es mayor que cero y se encuentra dentro del rango definido, el valor es correcto
        es_valido= True
      else:
          print("El número debe ser mayor a cero y estar dentro del rango de: "+str(valor_incial_rango)+" a "+str(valor_final_rango))
    except ValueError:
      print("El valor ingresado no es permitido")
  return valor_usuario

#Programa principal
valor_inicial= obtener_numero_valido(4,25)
print(valor_inicial)