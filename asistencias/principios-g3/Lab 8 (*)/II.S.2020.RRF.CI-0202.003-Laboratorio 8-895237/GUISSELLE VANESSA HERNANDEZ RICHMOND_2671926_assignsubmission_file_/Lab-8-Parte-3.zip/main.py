#Problema 3.

def obtener_número_válido(primer_valor, segundo_valor):
  es_válido = False
  while es_válido == False:
   try:
     valor_usuario = int(input("\nIngrese un número:"))
     if 0 < valor_usuario < 100 and primer_valor < valor_usuario < segundo_valor:
       es_válido = True
       print("El número ingresado está dentro del rango")
     elif valor_usuario < 0:
       print("\nEl número debe ser mayor a cero")
     else: 
       print("El número debe estar dentro del rango")
   except ValueError:
     print("\nEl número no es permitido")
  return valor_usuario

#Programa principal(de edad)
primer_valor = 20
segundo_valor = 70
valor = obtener_número_válido(20, 70)

print("!Gracias por utilizar el programa¡")

