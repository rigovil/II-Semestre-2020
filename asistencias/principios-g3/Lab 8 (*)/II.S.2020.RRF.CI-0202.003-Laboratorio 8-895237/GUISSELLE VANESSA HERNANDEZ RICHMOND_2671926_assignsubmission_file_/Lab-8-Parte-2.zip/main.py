#Problema 2

def determinar_valor_cercano (objetivo, segundo_valor, tercer_valor):
  diferencia_segundo_valor = float(abs(objetivo - segundo_valor))
  diferencia_tercer_valor = float(abs(objetivo - tercer_valor))
  valor_cercano = segundo_valor or tercer_valor
  if diferencia_segundo_valor < diferencia_tercer_valor:
    valor_cercado = segundo_valor
    print("\nEl valor más cercano al objetivo es el segundo.")
  elif diferencia_segundo_valor == diferencia_tercer_valor:
    valor_cercano = segundo_valor and tercer_valor  
    print("\nTanto el segundo como el tercer valor tienen la misma cercanía con el objetivo.")
  elif diferencia_tercer_valor < diferencia_segundo_valor:
    valor_cercano = tercer_valor
    print("\nEl valor más cercano al objetivo es el tercero.")
  return valor_cercano

#Programa Principal
try:
 objetivo = float(input("Ingrese un valor objetivo:"))
 segundo_valor =  float(input("\nIngrese un segundo valor:"))
 tercer_valor = float(input("\nIngrese un tercer valor:"))

 resultado = determinar_valor_cercano(objetivo, segundo_valor, tercer_valor)
 
except ValueError:
  print("El valor ingresado no es permitido")

print("¡Gracias por usar el programa!")