#Calculadora
#Tres opciones:
#Sumar dos números positivos
#Restar dos números positivos
#Salir 

#Métodos

#Sumar 
def sumar(primer_valor, segundo_valor):
  resultado = primer_valor + segundo_valor
  return resultado 

#Restar
def restar(primer_valor, segundo_valor):
  resultado = primer_valor - segundo_valor
  return resultado

#multiplicar
def multiplicar(primer_valor, segundo_valor):
  resultado = primer_valor * segundo_valor
  return resultado

#Dividir
def dividir(primer_valor, segundo_valor):
  resultado = primer_valor / segundo_numero
  return resultado

#devolver numero mas cercano al primero
def revisar_diferencia(primer_valor, segundo_valor, tercer_valor):
  numero_1 = primer_valor - segundo_valor
  numero_2 = primer_valor - tercer_valor


  numero_preresultado_1 = abs(numero_1)
  numero_preresultado_2 = abs(numero_2)

  pre_resultado = numero_preresultado_1 - numero_preresultado_2

  resultado = 0

  if pre_resultado >= 0:
    resultado = tercer_valor

  
  if pre_resultado <= 0:
    resultado = segundo_valor

  return resultado



 

#Programa principal 

print("Bienvenido al programa de calculadora")

terminar_programa = False

while terminar_programa == False:
  #Desplegar menú
  print("\nMenú de opciones\n")
  print("1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Encontrar numero cercano\n6. Salir")
  
  try:
    operacion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if operacion_usuario == 1:

      #Suma
      print("\nSUMA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_suma = sumar(primer_numero, segundo_numero)
              print("\nEl resultado de la suma es: ",resultado_suma)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 2:
      #Resta
      print("\nRESTA\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_resta = restar(primer_numero, segundo_numero)
              print("\nEl resultado de la resta es: ",resultado_resta)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")

    elif operacion_usuario == 3:
      #multiplicación
      print("\nMULTIPLICACIÓN\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_multiplicacion = multiplicar(primer_numero, segundo_numero)
              print("\nEl resultado de la multiplicación es: ",resultado_multiplicacion)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")


    elif operacion_usuario == 4:
      #división
      print("\nDIVISIÓN\n")
      #Solicitar los valores al usuario
      
      numeros_validos = False
      
      while numeros_validos == False:
        try:
          primer_numero = float(input("Ingrese el primer valor: "))
          if primer_numero > 0: 
            segundo_numero = float(input("Ingrese el segundo valor: "))
            if segundo_numero > 0:
              numeros_validos = True
              resultado_division = dividir(primer_numero, segundo_numero)
              print("\nEl resultado de la división es: ",resultado_division)
            else:
              print("El número ingresado debe ser mayor a cero")
          else:
            print("El número ingresado debe ser mayor a cero") 
        except ValueError:
          print("El valor ingresado no es permitido")
    
    #encontrar valor cercano
    elif operacion_usuario == 5:
      #demostracion
      print("\nNUMERO CERCANO")
      print("\nEsta seccion sirve para devolver el numero mas cercano al primer valor que ingrese, acontinuacion un ejemplo:")
      print("primer valor = 1\nsegundo valor = 5\ntercer valor = 4")
      valor_ejemplo_1 = 1
      valor_ejemplo_2 = 5
      valor_ejemplo_3 = 4

      resultado_diferencia_ejemplo = revisar_diferencia(valor_ejemplo_1,valor_ejemplo_2 ,valor_ejemplo_3) 
      print("\nel numero mas cercano a el primer valor es:", resultado_diferencia_ejemplo)
      
      primer_numero = float(input("\nIngrese el primer valor: "))
      segundo_numero = float(input("Ingrese el segundo valor: "))
      tercer_numero = float(input("Ingrese el tercer valor: "))

      resultado_diferencia = revisar_diferencia(primer_numero, segundo_numero, tercer_numero)
      print("\n el numero mas cercano a el primer valor es:", resultado_diferencia

     #salir
    elif operacion_usuario == 6:
      terminar_programa = True
    else:
      print("La operación indicada no es correcta")
  except ValueError:
    print("El valor ingresado no es permitido")