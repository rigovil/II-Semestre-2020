#metodos

#Problema 3, numero positivo
def numero_positivo_metodo (uno):
  estado = False
  valor_int = (uno)

  
  while estado == False:
    try:
      valor_int = int(input("\nIngrese el valor: "))
      if valor_int > 0:
        estado = True
        return valor_int
    except ValueError:
      estado = False


#Problema 4, numero positivo en rango
def numero_positivo_rango (uno):
  estado = False
  valor_int = (uno)

  valor_minimo = int(input("defina el rango\nValor minimo: "))
  valor_maximo = int(input("Valor m[aximo: "))


  while estado == False:
    try:
      valor_int = int(input("\nIngrese el valor: "))
      if valor_int >= valor_minimo and valor_int <= valor_maximo:
        estado = True
        return valor_int
    except ValueError:
      estado = False




#programa principal
print("Problema 3:")
uno = ("uno")
numero_positivo = numero_positivo_metodo (uno)
print(numero_positivo)

print ("\nProblema 4")
uno = ("uno")
numero_positivo_2 = numero_positivo_rango(uno)
print(numero_positivo_2)