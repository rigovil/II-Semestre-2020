#Determinación de número más cercano al primero
def determinar_numero_cercano(primer_valor, segundo_valor, tercer_valor):
  diferencia_1 = abs(primer_valor - segundo_valor)
  diferencia_2 = abs(primer_valor - tercer_valor)
  if diferencia_1 < diferencia_2:
    resultado = segundo_valor
  else:
    resultado = tercer_valor

  return resultado

#Método de ingreso de número entero
def obtener_numero_entero():
  control_ingreso = False
  while control_ingreso == False:
    try:
      ingreso_usuario = int(input("Ingrese un número entero positivo: "))
      if ingreso_usuario <= 0:
        print("El número ingresado debe ser positivo")
      else:
        numero_entero = ingreso_usuario
        control_ingreso = True
    except ValueError:
      print("El valor ingresado no es permitido")

  return numero_entero

#Método de ingreso de número entero con rango (opcional)
def obtener_numero_entero_rango(primer_valor, segundo_valor):
  control_ingreso = False
  while control_ingreso == False:
    try:
      ingreso_usuario = int(input("Ingrese un número entero positivo: "))
      if ingreso_usuario <= 0:
        print("El número ingresado debe ser positivo")
      elif not primer_valor < ingreso_usuario < segundo_valor:
        print("El número ingresado debe encontrarse entre",primer_valor,"y",segundo_valor)
      else:
        numero_entero = ingreso_usuario
        control_ingreso = True
    except ValueError:
      print("El valor ingresado no es permitido")

  return numero_entero

#Programa principal
#Prueba de método de determinar número cercano
resultado = determinar_numero_cercano(3, 1, -1)
print(resultado)

#Prueba de metodo para obtener número entero
resultado_prueba = obtener_numero_entero()
print(resultado_prueba)

#Prueba de metodo para obtener número entero con rango
resultado_prueba_2 = obtener_numero_entero_rango(5, 22)
print(resultado_prueba_2)

#fin de Programa