#Método para obtener un número valido; que debe ser entero positivo y además estar en un intervalo de 1 a 10
def obtener_numero_valido():
 
 es_valido = False

 while es_valido == False:
  try:
    valor_usuario = int(input("\nIngrese un numero entero positivo: "))
    if 1 <= valor_usuario and valor_usuario <= 10:
    #Valor correcto
     es_valido = True
    else:
     print("\nEl número debe ser un entero positivo entre 1 y 10")
  except ValueError:
    print("\nEl valor ingresado no es permitido") 

 return valor_usuario 


#Programa principal

valor_inicial = obtener_numero_valido()
print("\nCorrecto!", valor_inicial, "es un numero entero positivo entre 1 y 10")