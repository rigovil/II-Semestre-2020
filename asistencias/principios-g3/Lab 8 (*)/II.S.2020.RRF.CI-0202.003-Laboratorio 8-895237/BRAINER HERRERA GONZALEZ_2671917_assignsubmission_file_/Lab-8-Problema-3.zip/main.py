#Método para obtener un número valido; que debe ser entero positivo
def obtener_numero_valido():

 es_valido = False

 while es_valido == False:
  try:
    valor_usuario = int(input("\nIngrese un numero entero positivo: "))
    if valor_usuario > 0:
    #Valor correcto
     es_valido = True
    else:
     print("\nEl número debe ser mayor a cero")
  except ValueError:
    print("\nEl valor ingresado no es permitido") 

 return valor_usuario 

#Programa principal

valor_inicial = obtener_numero_valido()
print("\nCorrecto!", valor_inicial, "es un numero entero positivo")


