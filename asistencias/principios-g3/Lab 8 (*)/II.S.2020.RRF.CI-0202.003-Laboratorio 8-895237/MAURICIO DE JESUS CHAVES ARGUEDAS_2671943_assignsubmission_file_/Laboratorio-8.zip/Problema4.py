#Métodos
#Método para buscar un número entero positivo
def buscar_entero_positivo(primer_valor_rango, segundo_valor_rango):
  #Se declara la variable para mantener el ciclo hasta que se ingrese un número válido
  numero_objetivo = False

  while numero_objetivo == False:
    try:
      #Se declara la variable que va a almmacenar el número ingresado por el ususario
      #numero_usuario se declara como un entero
      numero_usuario = int(input("\nIngrese un número: "))
      #Si el número ingresado es positivo:
      
      if numero_usuario > 0:
        #Cuando el primer límite del rango es mayor o igual al segundo
        if primer_valor_rango >= segundo_valor_rango:
          #Si numero_usuario se encuentra dentro del rango
          if (numero_usuario <= primer_valor_rango) and (numero_usuario >= segundo_valor_rango):
            #Retorna numero_usuario
            return numero_usuario
            #Cambia numero_objetivo para concluir el while
            numero_objetivo = True
          #Si se encuentra fuera del rango imprime un mensaje
          else:
            print("\nEl número ingresado no entra en el rango")
       
        #Cuando el segundo límite del rango es mayor que el primero
        else:
          #Si numero_usuario se encuentra dentro del rango
          if (numero_usuario >= primer_valor_rango) and (numero_usuario <= segundo_valor_rango):
            #Retorna numero_usuario
            return numero_usuario
            #Cambia numero_objetivo para concluir el while
            numero_objetivo = True
           #Si se encuentra fuera del rango imprime un mensaje
          else:
            print("\nEl número ingresado no entra en el rango")

      #Si el número ingresado no es positivo:
      else:
        #Se imprime un mensaje y repite el while
        print("\nEl número ingresado no es valido")
    
    #Si se ingresa un valor no permitido se imprime un mensaje y se repite el while
    except ValueError:
      print("\nEl número ingresado no es válido")


#Programa principal
#Mensaje inicial
print("Programa para determinar un número con especificaciones")

numero_rango_uno = int(input("Ingrese el primer número del rango: "))
numero_rango_dos = int(input("Ingrese el segundo número del rango: "))

#Se imprime un mensaje y se invoca el método buscar_entero_positivo para mostrar el resultado del programa
print("\nEl número",buscar_entero_positivo(numero_rango_uno, numero_rango_dos), "cumple con las condiciones necesarias")