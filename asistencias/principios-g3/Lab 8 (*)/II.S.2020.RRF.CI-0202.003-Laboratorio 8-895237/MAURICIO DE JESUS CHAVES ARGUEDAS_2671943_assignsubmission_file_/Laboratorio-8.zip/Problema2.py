#Métodos
#Método para determinar el número más cercano a un objetivo
def diferencia_menor(objetivo, primer_numero, segundo_numero):
  #Se declara la variable difencia_1 que almecena la diferencia en valor absoluto entre el objetivo y primer_numero
  diferencia_1 = abs(objetivo - primer_numero)
  #Se declara la variable difencia_2 que almecena la diferencia en valor absoluto entre el objetivo y segundo_numero
  diferencia_2 = abs(objetivo - segundo_numero)

  #Si diferencia_1 es mayor quiere decir que segundo_numero es más cercano al objetivo y lo retorna
  if diferencia_1 > diferencia_2:
    return segundo_numero
  #Si diferencia_1 no es mayor quiere decir que primer_numero es igual o más cercano al objetivo 
  else:
    return primer_numero

#Programa principal
print("Programa para determinar el número más cercano a un objetivo")

#Se declara la variable que va a contener el número objetivo
objetivo = float(input("\nIngrese el número objetivo: "))
#Se declaran las variables que van a contener los números a evaluar
primer_numero = float(input("Ingrese el primer número a evaluar: "))
segundo_numero = float(input("Ingrese el segundo número a evaluar: "))

#Se invoca el método diferencia_menor y se almacena en la variable numero_cercano
numero_cercano = diferencia_menor(objetivo, primer_numero, segundo_numero)

#Se imprime un mensaje de resultado junto con numero_cercano
print("\nEl número más cercano al objetivo es:", numero_cercano)