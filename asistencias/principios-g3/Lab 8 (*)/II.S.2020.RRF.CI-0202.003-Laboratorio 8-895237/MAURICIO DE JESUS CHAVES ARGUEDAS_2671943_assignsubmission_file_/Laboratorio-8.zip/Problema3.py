#Métodos
#Método para buscar un número entero positivo
def buscar_entero_positivo():
  #Se declara la variable para mantener el ciclo hasta que se ingrese un número válido
  numero_objetivo = False
  while numero_objetivo == False:
    try:
      #Se declara la variable que va a almmacenar el número ingresado por el ususario
      #numero_usuario se declara como un entero
      numero_usuario = int(input("\nIngrese un número: "))
      #Si el número ingresado es positivo:
      if numero_usuario > 0:
        #Retorna numero_usuario
        return numero_usuario
        #Cambia numero_objetivo para concluir el while
        numero_objetivo = True
      #Si el número ingresado no es positivo:
      else:
        #Se imprime un mensaje y repite el while
        print("\nEl número ingresado no es valido")
    
    #Si se ingresa un valor no permitido se imprime un mensaje y se repite el while
    except ValueError:
      print("\nEl número ingresado no es válido")


#Programa principal
#Mensaje inicial
print("Programa para determinar un número con especificaciones")
#Se imprime un mensaje y se invoca el método buscar_entero_positivo para mostrar el resultado del programa
print("\nEl número",buscar_entero_positivo(), ",cumple con las condiciones necesarias")