# Método para conocer un valor cercano

def determinar_valor_cercano(primer_valor, segundo_valor, tercer_valor):
  valor_cercano = 0
  diferencia_segundo_valor = abs(primer_valor-segundo_valor)
  diferencia_tercer_valor = abs(primer_valor-tercer_valor)

  if diferencia_segundo_valor <= diferencia_tercer_valor:
    valor_cercano = segundo_valor

  elif diferencia_tercer_valor <= diferencia_segundo_valor:
    valor_cercano = tercer_valor

  return valor_cercano


# Programa Principal
# Se le solitan tres valores al usuario

primero = float(input("Ingrese el primer valor: "))
segundo = float(input("Ingrese el segundo valor: "))
tercero = float(input("Ingrese el tercero valor: "))

resultado = determinar_valor_cercano(primero, segundo, tercero)

print(f"\nEl valor más cercano al primer valor", resultado)