# Método para solicitarle el valor al usuario así como para indicarle cualquier error que cometa


def obtener_numero_valido ():
  numero_valido = False
  while numero_valido == False:
    try:
      valor_usuario = int(input("\nIngrese un numero entero positivo: "))
      if valor_usuario > 0:
        numero_valido = True
      else:
        print ("\nEl numero ingresado debe ser mayor a cero.")
    except ValueError:
      print("\nEl valor ingresado no es permitido")
    
  return valor_usuario


# Se guarda en una variable el método anterior para que funcione correctamente e imprimir un mensaje de que el valor ingresado es correcto
valor_inicial = obtener_numero_valido()
print("\nEl valor "+ str(valor_inicial) +" sí es válido")