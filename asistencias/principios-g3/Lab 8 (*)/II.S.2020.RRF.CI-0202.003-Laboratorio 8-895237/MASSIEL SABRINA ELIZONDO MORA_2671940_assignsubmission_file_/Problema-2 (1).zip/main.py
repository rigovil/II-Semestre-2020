
#método para calcular residuo
def residuo(numero_objetivo,numero1,numero2):
  residuo1 = float(numero_objetivo) % float(numero1)
  residuo2 = float(numero_objetivo) % float(numero2)
  resultado = 0
  if residuo1 < residuo2:
    resultado = numero1
  elif residuo1 > residuo2:
    resultado = numero2
  return resultado


numero1 = float(input("Ingrese el primer número: "))
numero2 = float(input("Ingrese el segundo número: "))
numero3 = float(input("Ingrese el tercer número: "))


resultado = residuo(numero1,numero2,numero3)
print(resultado)