def entero(): 
  
  numero = False

  while numero == False:
    try:
      numero1 = int(input("Ingrese un número: "))
      if numero1 < 0:
        numero = False
      else:
        numero = True
        resultado = print(numero1)
    except ValueError: 
      numero = False
  return resultado 
  
numero1 = entero()




