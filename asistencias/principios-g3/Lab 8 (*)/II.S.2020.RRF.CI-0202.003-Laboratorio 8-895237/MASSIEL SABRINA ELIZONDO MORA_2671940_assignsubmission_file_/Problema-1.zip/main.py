#método para suma
def suma(primer_valor,segundo_valor):
  resultado = print( "El resultado de la operación es: ", int(primer_valor) + int(segundo_valor))
  return resultado

#método para resta
def resta(primer_valor,segundo_valor):
  resultado = print( "El resultado de la operación es: ", int(primer_valor) - int(segundo_valor))
  return resultado

#método para división
def division(primer_valor,segundo_valor):
  resultado = print( "El resultado de la operación es: ", int(primer_valor) / int(segundo_valor))
  return resultado

#método para multiplicación
def multiplicacion(primer_valor,segundo_valor):
  resultado = print( "El resultado de la operación es: ", int(primer_valor) * int(segundo_valor))
  return resultado

valor_ingresado = True

while valor_ingresado == True:
  try:
    print("Bienvenido al programa de calculadora \n\n Menú de opciones: \n\n 1. Suma \n 2. Resta \n 3. División \n 4. Multiplicación \n\n")
    opcion_usuario = int(input("Ingrese la operación que desea realizar: "))
    if opcion_usuario == 1:
      primer_valor = input("Ingrese el primer valor: ")
      segundo_valor = input("Ingrese el segundo valor: ")
      suma(primer_valor,segundo_valor)
      valor_ingresado = True
    elif opcion_usuario == 2:
      primer_valor = input("Ingrese el primer valor: ")
      segundo_valor = input("Ingrese el segundo valor: ")
      resta(primer_valor,segundo_valor)
      valor_ingresado = True
    elif opcion_usuario == 3:
      primer_valor = input("Ingrese el primer valor: ")
      segundo_valor = input("Ingrese el segundo valor: ")
      division(primer_valor,segundo_valor)
      valor_ingresado = True
    elif opcion_usuario == 4:
      primer_valor = input("Ingrese el primer valor: ")
      segundo_valor = input("Ingrese el segundo valor: ")
      multiplicacion(primer_valor,segundo_valor)
      valor_ingresado = True
    
    
  except ValueError:
    print("El valor ingresado no está permitido")
  except ZeroDivisionError:
    print("La división de números entre cero no está permitida")
  except Exception:
    print("Ha ocurrido un error")
